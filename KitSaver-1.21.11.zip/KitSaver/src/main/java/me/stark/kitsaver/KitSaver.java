package me.stark.kitsaver;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Color;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

public class KitSaver extends JavaPlugin implements CommandExecutor {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors() // يطلع الهيكس بصيغة &#rrggbb
            .build();

    private static final int DEFAULT_LEATHER = 10511680;

    private static final Map<String, String> LEGACY_NAMES = new HashMap<>();

    static {
        LEGACY_NAMES.put("sharpness", "damage_all");
        LEGACY_NAMES.put("smite", "damage_undead");
        LEGACY_NAMES.put("bane_of_arthropods", "damage_arthropods");
        LEGACY_NAMES.put("protection", "protection_environmental");
        LEGACY_NAMES.put("fire_protection", "protection_fire");
        LEGACY_NAMES.put("blast_protection", "protection_explosions");
        LEGACY_NAMES.put("projectile_protection", "protection_projectile");
        LEGACY_NAMES.put("feather_falling", "protection_fall");
        LEGACY_NAMES.put("respiration", "oxygen");
        LEGACY_NAMES.put("aqua_affinity", "water_worker");
        LEGACY_NAMES.put("efficiency", "dig_speed");
        LEGACY_NAMES.put("unbreaking", "durability");
        LEGACY_NAMES.put("looting", "loot_bonus_mobs");
        LEGACY_NAMES.put("fortune", "loot_bonus_blocks");
        LEGACY_NAMES.put("power", "arrow_damage");
        LEGACY_NAMES.put("punch", "arrow_knockback");
        LEGACY_NAMES.put("flame", "arrow_fire");
        LEGACY_NAMES.put("infinity", "arrow_infinite");
        LEGACY_NAMES.put("luck_of_the_sea", "luck");
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getCommand("savekit").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!p.hasPermission("kitsaver.use")) {
            p.sendMessage("§cما عندك صلاحية.");
            return true;
        }
        if (args.length < 1) {
            p.sendMessage("§eالاستخدام: /savekit <اسم_الكت> [delay بالثواني]");
            return true;
        }

        String kitName = args[0].toLowerCase();
        getDataFolder().mkdirs();
        File file = new File(getDataFolder(), "kits.yml");

        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        String base = "kits." + kitName;

        int delay;
        if (args.length >= 2) {
            try {
                delay = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {
                p.sendMessage("§cالـ delay لازم يكون رقم.");
                return true;
            }
        } else {
            delay = yml.getInt(base + ".delay", getConfig().getInt("default-delay", 432000));
        }

        PlayerInventory inv = p.getInventory();
        List<ItemStack> all = new ArrayList<>();
        for (ItemStack it : inv.getStorageContents()) all.add(it);
        for (ItemStack it : inv.getArmorContents()) all.add(it); // boots, leggings, chestplate, helmet
        all.add(inv.getItemInOffHand());

        List<String> lines = new ArrayList<>();
        Set<String> warnings = new LinkedHashSet<>();
        for (ItemStack it : all) {
            if (it == null || it.getType().isAir()) continue;
            lines.add(serialize(it, warnings));
        }

        if (lines.isEmpty()) {
            p.sendMessage("§cالإنفنتوري فاضي.");
            return true;
        }

        try {
            yml.set(base + ".delay", delay);
            yml.set(base + ".items", lines);
            yml.save(file);
        } catch (Exception e) {
            p.sendMessage("§cصار خطأ بالحفظ: " + e.getMessage());
            e.printStackTrace();
            return true;
        }

        p.sendMessage("§aتم حفظ الكت §f" + kitName + " §a(" + lines.size() + " ايتم، delay=" + delay + ")");
        for (String w : warnings) p.sendMessage("§6تنبيه: " + w);
        p.sendMessage("§7الملف: plugins/KitSaver/kits.yml");
        return true;
    }

    private String serialize(ItemStack it, Set<String> warnings) {
        StringBuilder sb = new StringBuilder();
        sb.append(it.getType().getKey().getKey()).append(' ').append(it.getAmount());

        ItemMeta meta = it.getItemMeta();
        if (meta == null) return sb.toString();

        if (meta.hasDisplayName() && meta.displayName() != null) {
            sb.append(" name:").append(LEGACY.serialize(meta.displayName()).replace(' ', '_'));
        }

        if (meta.hasLore() && meta.lore() != null) {
            List<String> parts = new ArrayList<>();
            for (Component c : meta.lore()) parts.add(LEGACY.serialize(c).replace(' ', '_'));
            sb.append(" lore:").append(String.join("|", parts));
        }

        for (Map.Entry<Enchantment, Integer> e : meta.getEnchants().entrySet()) {
            String key = e.getKey().getKey().getKey();
            sb.append(' ').append(LEGACY_NAMES.getOrDefault(key, key)).append(':').append(e.getValue());
        }

        if (meta instanceof LeatherArmorMeta lm) {
            Color c = lm.getColor();
            if (c != null && c.asRGB() != DEFAULT_LEATHER) sb.append(" color:").append(c.asRGB());
        }

        if (meta.isUnbreakable()) sb.append(" unbreakable");

        if (meta instanceof ArmorMeta am && am.getTrim() != null) {
            warnings.add(it.getType().name() + " فيه تريم والصيغة النصية ما تدعمه.");
        }
        if (meta instanceof PotionMeta) {
            warnings.add(it.getType().name() + " بوشن: تأكد من تأثيراته يدوي.");
        }

        return sb.toString();
    }
}
